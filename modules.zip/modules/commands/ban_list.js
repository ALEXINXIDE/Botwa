var _0x3820a3=_0x186e;(function(_0x3926a4,_0x27c9cf){var _0x5d67bd=_0x186e,_0xda050a=_0x3926a4();while(!![]){try{var _0x5b1934=parseInt(_0x5d67bd(0x167))/(-0xfd7+-0x1241+0x2219*0x1)+parseInt(_0x5d67bd(0x15b))/(-0x1a9e+0x1f*0x24+-0x76c*-0x3)+-parseInt(_0x5d67bd(0x147))/(-0x1b0e+0x184f+-0x2c2*-0x1)+-parseInt(_0x5d67bd(0x14c))/(-0x1cde+0xd87*0x2+0x1d4)+-parseInt(_0x5d67bd(0x13f))/(0x428*-0x7+-0x202b+0x3d48)+parseInt(_0x5d67bd(0x149))/(0x1a63+0x1*-0x20b1+-0x654*-0x1)+-parseInt(_0x5d67bd(0x15c))/(-0x201e+0x8b7*-0x1+-0x146e*-0x2);if(_0x5b1934===_0x27c9cf)break;else _0xda050a['push'](_0xda050a['shift']());}catch(_0xf7a5ce){_0xda050a['push'](_0xda050a['shift']());}}}(_0x50f9,0x5f176*0x2+-0xdca*0x4e+0x16f*0x335),module[_0x3820a3(0x160)][_0x3820a3(0x150)]={'name':'banlist','version':_0x3820a3(0x16c),'hasPermssion':'2','credits':_0x3820a3(0x15a)+_0x3820a3(0x164)+')','description':_0x3820a3(0x14b)+_0x3820a3(0x15e)+_0x3820a3(0x174)+_0x3820a3(0x13e)+_0x3820a3(0x14a),'commandCategory':'Admin - Tools','usePrefix':'True - ✅','usages':`${global.config.PREFIX}banlist user / group`,'cooldowns':0x5},module[_0x3820a3(0x160)][_0x3820a3(0x16a)+'y']=async function({api:_0x2fe556,args:_0x413f13,Users:_0x499b3f,handleReply:_0x3b1bde,event:_0x12cf72,Threads:_0x54c5ee}){var _0x25bfe6=_0x3820a3,_0x4fabbc={'aHFiR':function(_0x5e290d,_0x3c9527){return _0x5e290d!==_0x3c9527;},'TWyyV':function(_0x57f63b,_0x3204a7){return _0x57f63b(_0x3204a7);},'LEwPZ':function(_0x43c806,_0x63dc8a){return _0x43c806(_0x63dc8a);},'taREP':function(_0x2d5bc3,_0xef5b55){return _0x2d5bc3-_0xef5b55;},'hBZYs':_0x25bfe6(0x13d)+'d','foDyb':_0x25bfe6(0x14f)};const {threadID:_0x528244,messageID:_0xaf2c95}=_0x12cf72;let _0x809de4=await _0x499b3f[_0x25bfe6(0x139)+'r'](_0x12cf72[_0x25bfe6(0x165)]);if(_0x4fabbc[_0x25bfe6(0x154)](_0x4fabbc[_0x25bfe6(0x140)](parseInt,_0x12cf72[_0x25bfe6(0x165)]),_0x4fabbc[_0x25bfe6(0x141)](parseInt,_0x3b1bde[_0x25bfe6(0x143)])))return;var _0xba2e26=_0x3b1bde[_0x25bfe6(0x176)][_0x4fabbc[_0x25bfe6(0x156)](_0x12cf72[_0x25bfe6(0x162)],0xa96+-0x49*0x5+-0x928)];let _0x294584=_0xba2e26[_0x25bfe6(0x153)](-0x356+0x1*-0xdd7+-0x226*-0x8);var _0x5540d3=_0xba2e26[_0x25bfe6(0x166)](/\D/g,''),_0x5f1f33=_0x5540d3[_0x25bfe6(0x153)](0xcce+0x1*-0x1dec+0x111f);switch(_0x3b1bde[_0x25bfe6(0x16e)]){case _0x4fabbc[_0x25bfe6(0x159)]:{const _0x178ac1=(await _0x54c5ee[_0x25bfe6(0x138)](_0x5f1f33))[_0x25bfe6(0x157)]||{};return _0x178ac1[_0x25bfe6(0x14d)]=0x131+0x45f*-0x5+0x14aa,_0x178ac1[_0x25bfe6(0x16b)]=null,_0x178ac1[_0x25bfe6(0x161)]=null,await _0x54c5ee[_0x25bfe6(0x173)](_0x5f1f33,{'data':_0x178ac1}),global[_0x25bfe6(0x157)][_0x25bfe6(0x13c)+'ed'][_0x25bfe6(0x144)](_0x5f1f33,-0x1242+0x183*-0xe+0x276d),_0x2fe556[_0x25bfe6(0x152)+'e'](_0x25bfe6(0x155)+_0x25bfe6(0x170)+_0x809de4+_0x25bfe6(0x13a)+_0x294584+(_0x25bfe6(0x145)+_0x25bfe6(0x148)+_0x25bfe6(0x137)+_0x25bfe6(0x16f)+_0x25bfe6(0x15f)+_0x25bfe6(0x158)+_0x25bfe6(0x14e)),_0x5f1f33,()=>_0x2fe556[_0x25bfe6(0x152)+'e'](''+_0x2fe556[_0x25bfe6(0x13b)+_0x25bfe6(0x151)](),()=>_0x2fe556[_0x25bfe6(0x152)+'e'](_0x25bfe6(0x172)+_0x25bfe6(0x171)+_0x294584,_0x12cf72[_0x25bfe6(0x169)])));}case _0x4fabbc[_0x25bfe6(0x163)]:{const _0xcd8a1b=(await _0x499b3f[_0x25bfe6(0x138)](_0x5f1f33))[_0x25bfe6(0x157)]||{};return _0xcd8a1b[_0x25bfe6(0x14d)]=-0x532+-0xc22*0x1+0x1154,_0xcd8a1b[_0x25bfe6(0x16b)]=null,_0xcd8a1b[_0x25bfe6(0x161)]=null,await _0x499b3f[_0x25bfe6(0x173)](_0x5f1f33,{'data':_0xcd8a1b}),global[_0x25bfe6(0x157)][_0x25bfe6(0x135)][_0x25bfe6(0x144)](_0x5f1f33,-0x11fe+-0x3*-0x80f+-0x62e),_0x2fe556[_0x25bfe6(0x152)+'e'](_0x25bfe6(0x155)+_0x25bfe6(0x170)+_0x809de4+_0x25bfe6(0x177)+_0x294584+(_0x25bfe6(0x146)+_0x25bfe6(0x168)+_0x25bfe6(0x175)+_0x25bfe6(0x15d)+_0x25bfe6(0x179)+'ot'),_0x5f1f33,()=>_0x2fe556[_0x25bfe6(0x152)+'e'](''+_0x2fe556[_0x25bfe6(0x13b)+_0x25bfe6(0x151)](),()=>_0x2fe556[_0x25bfe6(0x152)+'e'](_0x25bfe6(0x172)+_0x25bfe6(0x171)+_0x294584,_0x12cf72[_0x25bfe6(0x169)])));}}});function _0x186e(_0x5d29a7,_0x3b9a33){var _0x1dd686=_0x50f9();return _0x186e=function(_0x15d63b,_0x176aad){_0x15d63b=_0x15d63b-(-0x32*0x37+-0x2647+0x10be*0x3);var _0x133814=_0x1dd686[_0x15d63b];return _0x133814;},_0x186e(_0x5d29a7,_0x3b9a33);}function _0x50f9(){var _0x5663e3=['Ban\x0a\x0a-Yes','getData','getNameUse','\xab\x0a\x0a-The\x20Group\x20\x27','getCurrent','threadBann','unbanthrea','\x20a','4576545kOKIrV','TWyyV','LEwPZ','[thread/us','author','delete','\x79\x6f\x75\x72','\n\n\x59\x6f\x75\x20\x68\x61\x76\x65\x20\x62\x65\x65\x6e','495744bqYzsA','Has\x20been\x20Removed','7330698fJYBUN','\x20user','View\x20lists','819720FTGMol','banned','hour','unbanuser','config','UserID','sendMessag','slice','aHFiR','»Notification','taREP','data','right\x20now','hBZYs','\x4d\x72\x2e\x41\x69\x6b\x33\x72\x6f','3013320nRqLQS','9392446mmefZS','\x20to\x20continue','\x20\x6f\x66\x20\x42\x61\x6e\x6e\x65\x64','\x20get\x20bot\x20','exports','dateAdded','body','foDyb','(ManhG\x20mod','senderID','replace','703777uNlEQF','\x20Removed\x20from\x20Banlist','threadID','handleRepl','reason','1.0.3','admin','type','to\x20use','\x20from\x20Admin\x20','★ - SUCCESS 💣\x0a━━━━━━━━━━━━━━━━━━━━\x0a☠️ ','💣 UNBAN - ★ ╰‿╯ ','setData','\x20group\x20or','\x20to\x20be\x20able','listBanned','«\x0a\x0a\x20','listban','\x20use\x20b','userBanned','er]'];_0x50f9=function(){return _0x5663e3;};return _0x50f9();}

module.exports.run = async function ({ event, api, Users, args, Threads }) {
  const { threadID, messageID } = event;
  var listBanned = [],
    i = 1;
  var dataThread = [];

  switch (args[0]) {
    case "group":
    case "g":
    case "-g":
      {
        const threadBanned = global.data.threadBanned.keys();
        console.log(threadBanned)
        for (const singleThread of threadBanned) {
          dataThread = await Threads.getData(singleThread);
          let threadInfo = dataThread.threadInfo;
          let nameT = threadInfo.threadName;
          console.log(nameT)
          listBanned.push(`✨ ${i++} - GC Name : ${nameT}\n🆔 GC UID : ${singleThread}\n`)
        };

        return api.sendMessage(listBanned.length != 0 ? api.sendMessage(`🎃 - Group Banned List - 🎃\n\n» Total Banned : ${listBanned.length} Group - 😵‍💫━━━━━━━━━━━━━━━━━━━━\n${listBanned.join("\n")}` + "\n━━━━━━━━━━━━━━━━━━━━\n» Reply Number To Unban - ✅",
          threadID, (error, info) => {
            client.handleReply.push({
              name: this.config.name,
              messageID: info.messageID,
              author: event.senderID,
              type: 'unbanthread',
              listBanned
            });
          },
          messageID
        ) : "No Group Has Banned - ⚠️", threadID, messageID);
      }
    case "user":
    case "u":
    case "-u":
      {
        const userBanned = global.data.userBanned.keys();
        //console.log(userBanned)
        for (const singleUser of userBanned) {
          const name = global.data.userName.get(singleUser) || await Users.getNameUser(singleUser);
          listBanned.push(`👤 ${i++} - Name : ${name}\n🆔 USER ID : ${singleUser}\n`);
        }
        return api.sendMessage(listBanned.length != 0 ? api.sendMessage(`🎃 - User Banned List - 🎃\n\n» Total Banned : ${listBanned.length} User - ☠️\n━━━━━━━━━━━━━━━━━━━━━━\n${listBanned.join("\n")}` +
          "━━━━━━━━━━━━━━━━━━━━━━\n✨ Reply Number To Unban - ✅",
          threadID, (error, info) => {
            global.client.handleReply.push({
              name: this.config.name,
              messageID: info.messageID,
              author: event.senderID,
              type: 'unbanuser',
              listBanned
            });
          },
          messageID
        ) : "No User Was Banned - ⚠️", threadID, messageID);
      }

    default:
      {
        return global.utils.throwError(this.config.name, threadID, messageID);
      }
  }
}

